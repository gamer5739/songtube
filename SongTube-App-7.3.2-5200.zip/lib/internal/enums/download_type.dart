enum DownloadType {
  audio,
  video
}